#!/usr/bin/env bash
# ==============================================================================
# RUSY PANEL - Local Development & Testing Installer (install-local.sh)
# ==============================================================================
# This script automates the setup, configuration, and execution of RUSY PANEL
# in local environments such as Ubuntu, Debian, WSL, Docker, CodeSandbox,
# GitHub Codespaces, Google IDX, or any Node.js-compatible Linux machine.
# ==============================================================================

# Strict mode: exit on errors, undefined variables, and pipe failures
set -euo pipefail

# --- Color Definitions & Logging Helpers ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

log_info() {
  echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
  echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
  echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1" >&2
}

# --- Beautiful Terminal Header ---
clear
echo -e "${CYAN}======================================================================${NC}"
echo -e "${PURPLE}    ____  __  ______  __  __   ____  ___    _   Relation / Local   ${NC}"
echo -e "${PURPLE}   / __ \\/ / / / ___/ \\ \\/ /  / __ \\/   |  / | / / ____/ /         ${NC}"
echo -e "${PURPLE}  / /_/ / /_/ /\\__ \\   \\  /  / /_/ / /| | /  |/ / __/ / /          ${NC}"
echo -e "${PURPLE} / _, _/ /_/ /___/ /   / /  / ____/ ___ |/ /|  / /___/ /___        ${NC}"
echo -e "${PURPLE}/_/ |_|\\____/____/   /_/  /_/   /_/  |_/_/ |_/_____/_____/        ${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo -e "${BLUE}          RUSY PANEL Local Development Setup & Installer             ${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo ""

# --- Step 1: Environment & OS Detection ---
log_info "Step 1: Detecting system environment..."

ENV_TYPE="Unknown"
if [ -n "${CODESPACES:-}" ]; then
  ENV_TYPE="GitHub Codespaces"
elif [ -n "${CODESANDBOX_SSE:-}" ]; then
  ENV_TYPE="CodeSandbox"
elif [ -n "${IDX_WORKSPACE_ID:-}" ]; then
  ENV_TYPE="Google IDX"
elif grep -qi microsoft /proc/version 2>/dev/null; then
  ENV_TYPE="WSL (Windows Subsystem for Linux)"
elif [ -f /.dockerenv ]; then
  ENV_TYPE="Docker Container"
else
  ENV_TYPE="Standard Linux Environment"
fi

log_success "Environment detected: ${ENV_TYPE}"

# Identify OS Distro
if [ -f /etc/os-release ]; then
  . /etc/os-release
  OS_NAME=$NAME
  OS_VERSION=$VERSION_ID
else
  OS_NAME=$(uname -s)
  OS_VERSION=$(uname -r)
fi
log_info "Operating System: ${OS_NAME} (Version: ${OS_VERSION})"

# --- Step 2: Validate Prerequisites & Install if Missing ---
log_info "Step 2: Verifying required software dependencies..."

# Function to check and install package on Debian/Ubuntu systems
ensure_debian_package() {
  local pkg_name=$1
  if ! command -v "$pkg_name" &>/dev/null; then
    log_warning "'$pkg_name' is missing."
    if command -v apt-get &>/dev/null; then
      log_info "Attempting to install '$pkg_name' via apt-get..."
      if [ "$(id -u)" -eq 0 ]; then
        apt-get update -y && apt-get install -y "$pkg_name"
      else
        sudo apt-get update -y && sudo apt-get install -y "$pkg_name"
      fi
    else
      log_error "Please install '$pkg_name' manually using your package manager and run the script again."
      exit 1
    fi
  fi
}

# Ensure basic utilities exist
ensure_debian_package "git"
ensure_debian_package "curl"

# Check Node.js
if ! command -v node &>/dev/null; then
  log_warning "Node.js is not installed."
  if command -v apt-get &>/dev/null; then
    log_info "Installing Node.js LTS via NodeSource..."
    if [ "$(id -u)" -eq 0 ]; then
      curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
      apt-get install -y nodejs
    else
      curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
      sudo apt-get install -y nodejs
    fi
  else
    log_error "Node.js is missing. Please install Node.js (v18 or higher) and run this script again."
    exit 1
  fi
fi

# Verify Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2)
NODE_MAJOR=$(echo "$NODE_VERSION" | cut -d'.' -f1)
if [ "$NODE_MAJOR" -lt 18 ]; then
  log_error "Your Node.js version (v${NODE_VERSION}) is too old. RUSY PANEL requires Node.js v18 or higher."
  exit 1
fi
log_success "Node.js is available: v${NODE_VERSION}"

# Check npm
if ! command -v npm &>/dev/null; then
  log_warning "npm is not installed. Installing npm..."
  if command -v apt-get &>/dev/null; then
    if [ "$(id -u)" -eq 0 ]; then
      apt-get install -y npm
    else
      sudo apt-get install -y npm
    fi
  else
    log_error "npm is missing. Please install npm and rerun."
    exit 1
  fi
fi
log_success "npm is available: v$(npm -v)"

# --- Step 3: Resolve Correct Project Directory ---
log_info "Step 3: Resolving project workspace directory..."

# Determine where the main panel-main source code is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
PROJECT_DIR=""

if [ -d "${SCRIPT_DIR}/panel-main" ]; then
  PROJECT_DIR="${SCRIPT_DIR}/panel-main"
elif [ -f "${SCRIPT_DIR}/package.json" ] && [ -d "${SCRIPT_DIR}/views" ]; then
  PROJECT_DIR="${SCRIPT_DIR}"
else
  # Check parents or current directory
  if [ -d "$(pwd)/panel-main" ]; then
    PROJECT_DIR="$(pwd)/panel-main"
  elif [ -f "package.json" ] && [ -d "views" ]; then
    PROJECT_DIR="$(pwd)"
  else
    log_error "Could not find 'panel-main' directory. Please run this script from the workspace root containing 'panel-main'."
    exit 1
  fi
fi

log_success "Project directory identified: ${PROJECT_DIR}"
cd "${PROJECT_DIR}"

# --- Step 4: Create Missing Storage Folders & Fix File Permissions ---
log_info "Step 4: Ensuring essential storage folders exist and setting permissions..."
mkdir -p storage
mkdir -p plugins
mkdir -p public/assets

if [ "$(id -u)" -ne 0 ] && [ -d storage ]; then
  chmod -R 755 storage plugins public/assets 2>/dev/null || true
fi
log_success "Folders prepared and permissions validated."

# --- Step 5: Install Dependencies with Download Retries ---
log_info "Step 5: Installing Node.js dependencies..."
log_info "This might take a few moments depending on your network connection..."

MAX_RETRIES=3
RETRY_COUNT=0
SUCCESS=false

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
  if npm install; then
    SUCCESS=true
    break
  else
    RETRY_COUNT=$((RETRY_COUNT + 1))
    log_warning "npm install failed. Retry $RETRY_COUNT of $MAX_RETRIES..."
    sleep 3
  fi
done

if [ "$SUCCESS" = false ]; then
  log_error "Failed to install dependencies after $MAX_RETRIES attempts."
  log_error "Troubleshooting Tips: Check your internet connection or run 'npm cache clean --force'."
  exit 1
fi
log_success "Dependencies installed successfully!"

# --- Step 6: Configure Port & Generate Config File ---
log_info "Step 6: Detecting port conflicts and generating config.json..."

DEFAULT_PORT=6009
FREE_PORT=$DEFAULT_PORT

# Check if default port 6009 is available using Node network test
is_port_free() {
  local port_to_test=$1
  node -e "
    const server = require('net').createServer();
    server.once('error', () => process.exit(1));
    server.once('listening', () => {
      server.close();
      process.exit(0);
    });
    server.listen($port_to_test);
  " 2>/dev/null
}

if is_port_free $FREE_PORT; then
  log_info "Port $FREE_PORT is available."
else
  log_warning "Port $FREE_PORT is already in use."
  while true; do
    FREE_PORT=$((FREE_PORT + 1))
    log_info "Testing port $FREE_PORT..."
    if is_port_free $FREE_PORT; then
      log_success "Found an available port: $FREE_PORT"
      break
    fi
  done
fi

# Ensure config.json exists by copying example if missing
if [ ! -f "config.json" ]; then
  log_info "Creating config.json from template..."
  cp example_config.json config.json
fi

# Update config.json with correct port and baseUri using a clean Node inline script
node -e "
const fs = require('fs');
const path = require('path');
const configPath = path.join(process.cwd(), 'config.json');

try {
  let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  config.port = $FREE_PORT;
  config.baseUri = 'http://localhost:' + $FREE_PORT;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
} catch (e) {
  console.error('Error rewriting config.json:', e);
  process.exit(1);
}
"

log_success "config.json generated and configured for port $FREE_PORT."

# --- Step 7: Build Static Assets ---
log_info "Step 7: Compiling frontend assets (Tailwind CSS)..."
if [ -f "./public/tw.conf" ]; then
  # Execute TailWind CLI compile directly
  if npx @tailwindcss/cli -i ./public/tw.conf -o ./public/assets/tailwind.css; then
    log_success "Tailwind CSS built successfully."
  else
    log_warning "Tailwind CLI build failed, fallback to standard CSS or let watch command handle compilation."
  fi
else
  log_warning "Tailwind configuration file public/tw.conf not found. Skipping standalone build."
fi

# --- Step 8: Startup and Summary Information ---
echo ""
echo -e "${CYAN}======================================================================${NC}"
echo -e "${GREEN}             RUSY PANEL LOCAL INSTALLATION COMPLETED                  ${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo -e "${BLUE}  Running Environment:  ${NC}${ENV_TYPE}"
echo -e "${BLUE}  Local Access URL:     ${NC}\033[1;32mhttp://localhost:${FREE_PORT}\033[0m"
echo -e "${BLUE}  Database Type:        ${NC}SQLite (sqlite://skyport.db)"
echo -e "${BLUE}  Server Directory:     ${NC}${PROJECT_DIR}"
echo -e "${CYAN}======================================================================${NC}"
echo ""

log_info "Starting the RUSY PANEL development server now..."
echo -e "${YELLOW}Press Ctrl+C to stop the server at any time.${NC}"
echo ""

# Execute the application start command
npm run start
