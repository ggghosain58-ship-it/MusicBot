#!/usr/bin/env bash
# ==============================================================================
# RUSY PANEL - Production VPS Deployer & Installer (install-vps.sh)
# ==============================================================================
# This script automates production-grade deployment of RUSY PANEL on VPS/Dedicated
# servers. It supports Debian, Ubuntu, AWS, DigitalOcean, Hetzner, etc.
# ==============================================================================

# Strict mode: exit on errors, undefined variables, and pipe failures
set -euo pipefail

# Check if run as root
if [ "$(id -u)" -ne 0 ]; then
  echo "This script must be run as root. Please run with sudo or as the root user." >&2
  exit 1
fi

# --- Color Definitions & Logging Helpers ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

log_info() {
  echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
  echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
  echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1" >&2
}

# --- Beautiful Terminal Header ---
clear
echo -e "${CYAN}======================================================================${NC}"
echo -e "${PURPLE}    ____  __  ______  __  __   ____  ___    _   Relation / VPS     ${NC}"
echo -e "${PURPLE}   / __ \\/ / / / ___/ \\ \\/ /  / __ \\/   |  / | / / ____/ /         ${NC}"
echo -e "${PURPLE}  / /_/ / /_/ /\\__ \\   \\  /  / /_/ / /| | /  |/ / __/ / /          ${NC}"
echo -e "${PURPLE} / _, _/ /_/ /___/ /   / /  / ____/ ___ |/ /|  / /___/ /___        ${NC}"
echo -e "${PURPLE}/_/ |_|\\____/____/   /_/  /_/   /_/  |_/_/ |_/_____/_____/        ${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo -e "${BLUE}         RUSY PANEL Enterprise Production VPS Deployer               ${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo ""

# --- Step 1: Detect Operating System ---
log_info "Step 1: Checking operating system compatibility..."
if [ -f /etc/os-release ]; then
  . /etc/os-release
  OS_DIST=$ID
  OS_VERSION=$VERSION_ID
else
  log_error "Unsupported operating system. This installer supports Ubuntu and Debian only."
  exit 1
fi

if [ "$OS_DIST" != "ubuntu" ] && [ "$OS_DIST" != "debian" ]; then
  log_error "Operating system '$OS_DIST' is not supported. Please use Ubuntu or Debian."
  exit 1
fi
log_success "Compatible OS detected: $NAME ($OS_VERSION)"

# --- Step 2: System Update & Install Base Utilities ---
log_info "Step 2: Performing system updates and installing core tools..."
apt-get update -y
apt-get upgrade -y
apt-get install -y curl wget git build-essential ufw software-properties-common gnupg lsb-release

# --- Step 3: Install Docker & Docker Compose ---
log_info "Step 3: Checking and installing Docker & Docker Compose..."
if ! command -v docker &>/dev/null; then
  log_info "Docker is not found. Installing Docker CE..."
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/$OS_DIST/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg --yes
  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/$OS_DIST \
    $(lsb_release -cs) stable" | tee /etc/apt/sources.list.p/docker.list > /dev/null
  apt-get update -y
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
fi

# Ensure docker service is running and enabled
systemctl enable docker
systemctl start docker
log_success "Docker & Docker Compose are configured and running."

# --- Step 4: Install Node.js LTS ---
log_info "Step 4: Setting up Node.js LTS (v20)..."
if ! command -v node &>/dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
log_success "Node.js installed: $(node -v)"

# --- Step 5: Configure System Firewall ---
log_info "Step 5: Setting up network firewall rules (UFW)..."
if command -v ufw &>/dev/null; then
  # Allow standard web service ports and SSH
  ufw allow 22/tcp comment 'SSH'
  ufw allow 80/tcp comment 'HTTP'
  ufw allow 443/tcp comment 'HTTPS'
  ufw allow 3000/tcp comment 'RUSY Panel Default'
  
  # Enable firewall non-interactively
  echo "y" | ufw enable
  log_success "Firewall (UFW) active. Allowed ports: 22, 80, 443, 3000."
else
  log_warning "UFW is not installed. Skipping firewall setup."
fi

# --- Step 6: Create Dedicated Non-Root App User ---
log_info "Step 6: Configuring non-root system user..."
APP_USER="rusypanel"
if ! id "$APP_USER" &>/dev/null; then
  log_info "Creating service user: $APP_USER"
  useradd -r -m -s /bin/bash "$APP_USER"
  # Add user to the docker group so they can manage containers
  usermod -aG docker "$APP_USER"
fi
log_success "Dedicated user '$APP_USER' created and added to 'docker' group."

# --- Step 7: Resolve App Code and Set Up Workspace ---
log_info "Step 7: Locating and preparing workspace..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
PROJECT_DIR=""

if [ -d "${SCRIPT_DIR}/panel-main" ]; then
  PROJECT_DIR="${SCRIPT_DIR}/panel-main"
elif [ -f "${SCRIPT_DIR}/package.json" ] && [ -d "${SCRIPT_DIR}/views" ]; then
  PROJECT_DIR="${SCRIPT_DIR}"
else
  log_error "Could not find 'panel-main' project directory. Please run this script inside the workspace."
  exit 1
fi

# Prepare folders and ownership
mkdir -p "${PROJECT_DIR}/storage"
mkdir -p "${PROJECT_DIR}/plugins"
mkdir -p "${PROJECT_DIR}/public/assets"

# Assign permissions and ownership to service user
chown -R "$APP_USER:$APP_USER" "$PROJECT_DIR"
log_success "Workspace located at $PROJECT_DIR and permissions assigned."

# --- Step 8: Install Production Dependencies & Build Static Assets ---
log_info "Step 8: Installing production dependencies & compiling CSS..."
cd "$PROJECT_DIR"

# Run dependency installation as the dedicated user
sudo -u "$APP_USER" npm install --production

# Build CSS using the Tailwind CLI
if [ -f "./public/tw.conf" ]; then
  sudo -u "$APP_USER" npx @tailwindcss/cli -i ./public/tw.conf -o ./public/assets/tailwind.css || true
fi
log_success "Dependencies built and assets compiled."

# --- Step 9: Interactive Cloudflare DNS & Domain Configuration ---
echo ""
echo -e "${CYAN}----------------------------------------------------------------------${NC}"
echo -e "${YELLOW}           CLOUDFLARE DNS & REVERSE PROXY CONFIGURATION               ${NC}"
echo -e "${CYAN}----------------------------------------------------------------------${NC}"
echo "You can automatically configure Cloudflare DNS and Let's Encrypt SSL."
read -p "Would you like to configure Cloudflare DNS? (y/n): " CF_CHOICE

DOMAIN_NAME=""
PUBLIC_IP=$(curl -s https://api.ipify.org || curl -s https://ifconfig.me)

if [[ "$CF_CHOICE" =~ ^[Yy]$ ]]; then
  while true; do
    read -p "Enter your Domain/Subdomain Name (e.g. panel.yourdomain.com): " DOMAIN_NAME
    read -p "Enter Cloudflare Zone ID: " CF_ZONE_ID
    read -sp "Enter Cloudflare API Token (Bearer Token): " CF_API_TOKEN
    echo ""

    log_info "Validating Cloudflare credentials and Zone..."
    CF_TEST=$(curl -s -o /dev/null -w "%{http_code}" -X GET "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID" \
      -H "Authorization: Bearer $CF_API_TOKEN" \
      -H "Content-Type: application/json")

    if [ "$CF_TEST" -eq 200 ]; then
      log_success "Cloudflare credentials authorized successfully!"
      
      # Query if DNS record exists
      log_info "Querying DNS record for $DOMAIN_NAME..."
      CF_RECORD_JSON=$(curl -s -X GET "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/dns_records?name=$DOMAIN_NAME&type=A" \
        -H "Authorization: Bearer $CF_API_TOKEN" \
        -H "Content-Type: application/json")

      RECORD_ID=$(echo "$CF_RECORD_JSON" | node -e "
        try {
          const data = JSON.parse(require('fs').readFileSync(0, 'utf-8'));
          if (data.success && data.result.length > 0) {
            console.log(data.result[0].id);
          } else {
            console.log('');
          }
        } catch(e) { console.log(''); }
      ")

      if [ -n "$RECORD_ID" ]; then
        log_info "Updating existing A record pointing to $PUBLIC_IP..."
        CF_RESP=$(curl -s -X PUT "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/dns_records/$RECORD_ID" \
          -H "Authorization: Bearer $CF_API_TOKEN" \
          -H "Content-Type: application/json" \
          --data "{\"type\":\"A\",\"name\":\"$DOMAIN_NAME\",\"content\":\"$PUBLIC_IP\",\"ttl\":120,\"proxied\":false}")
      else
        log_info "Creating new A record pointing to $PUBLIC_IP..."
        CF_RESP=$(curl -s -X POST "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/dns_records" \
          -H "Authorization: Bearer $CF_API_TOKEN" \
          -H "Content-Type: application/json" \
          --data "{\"type\":\"A\",\"name\":\"$DOMAIN_NAME\",\"content\":\"$PUBLIC_IP\",\"ttl\":120,\"proxied\":false}")
      fi

      CF_SUCCESS=$(echo "$CF_RESP" | node -e "
        try {
          const data = JSON.parse(require('fs').readFileSync(0, 'utf-8'));
          console.log(data.success);
        } catch(e) { console.log('false'); }
      ")

      if [ "$CF_SUCCESS" = "true" ]; then
        log_success "DNS Record configured cleanly!"
        break
      else
        log_error "Cloudflare DNS update failed. API Response: $CF_RESP"
        read -p "Would you like to retry? (y/n): " CF_RETRY
        if [[ ! "$CF_RETRY" =~ ^[Yy]$ ]]; then
          DOMAIN_NAME=""
          break
        fi
      fi
    else
      log_error "Authorization failed (HTTP Status $CF_TEST). Please check credentials."
      read -p "Would you like to retry? (y/n): " CF_RETRY
      if [[ ! "$CF_RETRY" =~ ^[Yy]$ ]]; then
        DOMAIN_NAME=""
        break
      fi
    fi
  done
else
  read -p "Enter your Domain Name if already pointed to this VPS, or leave blank to use Server IP: " DOMAIN_NAME
fi

# --- Step 10: Configure Nginx & Request SSL Cert (HTTPS) ---
USE_HTTPS=false
if [ -n "$DOMAIN_NAME" ]; then
  log_info "Configuring Nginx Reverse Proxy & SSL..."
  apt-get install -y nginx certbot python3-certbot-nginx

  NGINX_CONF="/etc/nginx/sites-available/rusypanel"
  cat <<EOF > "$NGINX_CONF"
server {
    listen 80;
    server_name $DOMAIN_NAME;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_buffering off;
    }
}
EOF

  ln -sf "$NGINX_CONF" "/etc/nginx/sites-enabled/rusypanel"
  rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true
  nginx -t && systemctl restart nginx
  log_success "Nginx proxy configuration generated successfully."

  log_info "Acquiring free SSL certificate via Let's Encrypt Certbot..."
  if certbot --nginx -d "$DOMAIN_NAME" --non-interactive --agree-tos --register-unsafely-without-email; then
    log_success "SSL certificate secured successfully!"
    USE_HTTPS=true
  else
    log_warning "SSL setup failed. Server will fallback to HTTP on port 80."
  fi
fi

# --- Step 11: Configure RUSY PANEL config.json ---
log_info "Step 11: Writing final configurations to config.json..."

if [ ! -f "config.json" ]; then
  sudo -u "$APP_USER" cp example_config.json config.json
fi

FINAL_DOMAIN="localhost"
FINAL_URI="http://$PUBLIC_IP:3000"

if [ -n "$DOMAIN_NAME" ]; then
  FINAL_DOMAIN="$DOMAIN_NAME"
  if [ "$USE_HTTPS" = true ]; then
    FINAL_URI="https://$DOMAIN_NAME"
  else
    FINAL_URI="http://$DOMAIN_NAME"
  fi
fi

# Update config using clean node script
sudo -u "$APP_USER" node -e "
const fs = require('fs');
const path = require('path');
const configPath = path.join(process.cwd(), 'config.json');

try {
  let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  config.port = 3000;
  config.domain = '$FINAL_DOMAIN';
  config.baseUri = '$FINAL_URI';
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
} catch(e) {
  console.error('Failed to configure config.json:', e);
  process.exit(1);
}
"
log_success "config.json written for $FINAL_URI."

# --- Step 12: Generate Systemd Service ---
log_info "Step 12: Installing Systemd Service for persistent execution..."

SERVICE_FILE="/etc/systemd/system/rusypanel.service"
cat <<EOF > "$SERVICE_FILE"
[Unit]
Description=RUSY PANEL Node Server
After=network.target docker.service

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$PROJECT_DIR
ExecStart=/usr/bin/node index.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable rusypanel.service
systemctl restart rusypanel.service

log_success "Systemd service rusypanel registered, enabled on boot, and started!"

# --- Step 13: Summary & Execution Information ---
echo ""
echo -e "${CYAN}======================================================================${NC}"
echo -e "${GREEN}             RUSY PANEL PRODUCTION VPS DEPLOYMENT COMPLETED            ${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo -e "${BLUE}  Panel Web URL:        ${NC}\033[1;32m${FINAL_URI}\033[0m"
echo -e "${BLUE}  Configured Domain:    ${NC}${FINAL_DOMAIN}"
echo -e "${BLUE}  Public IP Address:    ${NC}${PUBLIC_IP}"
echo -e "${BLUE}  Internal Port:        ${NC}3000 (Proxied by Nginx to 80/443)"
echo -e "${BLUE}  Systemd Service:      ${NC}rusypanel.service"
echo -e "${BLUE}  Service Status:       ${NC}Active / Running"
echo -e "${CYAN}======================================================================${NC}"
echo ""
echo -e "${PURPLE}Management Commands:${NC}"
echo -e "  - Start Panel:        ${GREEN}systemctl start rusypanel${NC}"
echo -e "  - Stop Panel:         ${RED}systemctl stop rusypanel${NC}"
echo -e "  - Restart Panel:      ${YELLOW}systemctl restart rusypanel${NC}"
echo -e "  - Real-time Logs:     ${CYAN}journalctl -u rusypanel -f -n 100${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo ""
