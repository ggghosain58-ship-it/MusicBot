#!/usr/bin/env bash
# ==============================================================================
# RUSY PANEL - Node Daemon Installer & Agent Configurator (install-node.sh)
# ==============================================================================
# This script automates the installation, registration, and configuration of
# the node agent (skyportd daemon) on any compatible Linux host or VPS.
# ==============================================================================

# Strict mode: exit on errors, undefined variables, and pipe failures
set -euo pipefail

# Check if run as root (necessary to orchestrate Docker containers)
if [ "$(id -u)" -ne 0 ]; then
  echo "This script must be run as root. Please run with sudo or as the root user." >&2
  exit 1
fi

# --- Color Definitions & Logging Helpers ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

log_info() {
  echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
  echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
  echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1" >&2
}

# --- Beautiful Terminal Header ---
clear
echo -e "${CYAN}======================================================================${NC}"
echo -e "${PURPLE}    ____  __  ______  __  __   ____  ___    _   Relation / Node    ${NC}"
echo -e "${PURPLE}   / __ \\/ / / / ___/ \\ \\/ /  / __ \\/   |  / | / / ____/ /         ${NC}"
echo -e "${PURPLE}  / /_/ / /_/ /\\__ \\   \\  /  / /_/ / /| | /  |/ / __/ / /          ${NC}"
echo -e "${PURPLE} / _, _/ /_/ /___/ /   / /  / ____/ ___ |/ /|  / /___/ /___        ${NC}"
echo -e "${PURPLE}/_/ |_|\\____/____/   /_/  /_/   /_/  |_/_/ |_/_____/_____/        ${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo -e "${BLUE}          RUSY PANEL Node Daemon & Agent Setup Utility               ${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo ""

# --- Step 1: Detect Operating System ---
log_info "Step 1: Checking operating system compatibility..."
if [ -f /etc/os-release ]; then
  . /etc/os-release
  OS_DIST=$ID
  OS_VERSION=$VERSION_ID
else
  log_error "Unsupported operating system. This installer supports Ubuntu and Debian only."
  exit 1
fi

if [ "$OS_DIST" != "ubuntu" ] && [ "$OS_DIST" != "debian" ]; then
  log_error "Operating system '$OS_DIST' is not supported. Please use Ubuntu or Debian."
  exit 1
fi
log_success "Compatible OS detected: $NAME ($OS_VERSION)"

# --- Step 2: System Update & Base Utilities ---
log_info "Step 2: Performing system updates and installing tools..."
apt-get update -y
apt-get install -y curl wget git build-essential gnupg lsb-release

# --- Step 3: Install Docker CE (Required for Running Game Servers) ---
log_info "Step 3: Checking and installing Docker & Docker Compose..."
if ! command -v docker &>/dev/null; then
  log_info "Docker is missing. Installing Docker CE..."
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/$OS_DIST/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg --yes
  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/$OS_DIST \
    $(lsb_release -cs) stable" | tee /etc/apt/sources.list.p/docker.list > /dev/null
  apt-get update -y
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
fi

systemctl enable docker
systemctl start docker
log_success "Docker Engine is active and configured."

# --- Step 4: Install Node.js LTS ---
log_info "Step 4: Checking Node.js runtime..."
if ! command -v node &>/dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
log_success "Node.js LTS ready: $(node -v)"

# --- Step 5: Install & Configure the Node Daemon ---
log_info "Step 5: Cloning and preparing Node agent (skyportd)..."
DAEMON_DIR="/etc/skyportd"

if [ ! -d "$DAEMON_DIR" ]; then
  log_info "Cloning daemon codebase from GitHub..."
  git clone https://github.com/skyport-team/daemon.git "$DAEMON_DIR"
else
  log_warning "Directory $DAEMON_DIR already exists. Pulling latest updates..."
  cd "$DAEMON_DIR"
  git pull || true
fi

cd "$DAEMON_DIR"

log_info "Installing agent software dependencies..."
npm install --production
log_success "Agent software prepared successfully."

# --- Step 6: Interactive Prompt & Registration ---
echo ""
echo -e "${CYAN}----------------------------------------------------------------------${NC}"
echo -e "${YELLOW}               NODE AGENT INITIAL REGISTRATION & BINDING              ${NC}"
echo -e "${CYAN}----------------------------------------------------------------------${NC}"
echo "To register this node, please input the details generated in the admin panel."
echo ""

while true; do
  read -p "Enter your RUSY PANEL URL (e.g. https://panel.example.com): " PANEL_URL
  read -p "Enter Node Configuration Key: " CONFIGURE_KEY

  if [ -z "$PANEL_URL" ] || [ -z "$CONFIGURE_KEY" ]; then
    log_error "Panel URL and Configuration Key are required to bind the Node."
    continue
  fi

  log_info "Initiating configuration handshake with the panel at $PANEL_URL..."
  
  # Run the registration command provided by skyportd CLI
  if npm run configure -- --panel "$PANEL_URL" --key "$CONFIGURE_KEY"; then
    log_success "Handshake succeeded! Node has been successfully linked!"
    break
  else
    log_error "Registration handshake failed. Please check your URL and Configuration Key and try again."
    read -p "Would you like to try again? (y/n): " RETRY_CHOICE
    if [[ ! "$RETRY_CHOICE" =~ ^[Yy]$ ]]; then
      log_warning "Handshake cancelled. You must configure the node manually."
      break
    fi
  fi
done

# --- Step 7: Create Systemd Service for Node Agent ---
log_info "Step 7: Creating Systemd Service for background execution..."

DAEMON_SERVICE_FILE="/etc/systemd/system/skyportd.service"
cat <<EOF > "$DAEMON_SERVICE_FILE"
[Unit]
Description=Skyport Daemon (Node Agent)
After=network.target docker.service
Requires=docker.service

[Service]
Type=simple
WorkingDirectory=$DAEMON_DIR
ExecStart=/usr/bin/node index.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable skyportd.service
systemctl restart skyportd.service

log_success "Systemd service 'skyportd' registered, enabled on boot, and running!"

# --- Step 8: Node Agent Summary ---
echo ""
echo -e "${CYAN}======================================================================${NC}"
echo -e "${GREEN}             RUSY PANEL DAEMON SETUP COMPLETED SUCCESSFULLY           ${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo -e "${BLUE}  Node Agent Path:      ${NC}${DAEMON_DIR}"
echo -e "${BLUE}  Linked Panel URL:     ${NC}${PANEL_URL}"
echo -e "${BLUE}  Systemd Service:      ${NC}skyportd.service"
echo -e "${BLUE}  Agent Status:         ${NC}Active / Connected"
echo -e "${CYAN}======================================================================${NC}"
echo ""
echo -e "${PURPLE}Management Commands:${NC}"
echo -e "  - Start Daemon:       ${GREEN}systemctl start skyportd${NC}"
echo -e "  - Stop Daemon:        ${RED}systemctl stop skyportd${NC}"
echo -e "  - Restart Daemon:     ${YELLOW}systemctl restart skyportd${NC}"
echo -e "  - Real-time Logs:     ${CYAN}journalctl -u skyportd -f -n 100${NC}"
echo -e "${CYAN}======================================================================${NC}"
echo ""
